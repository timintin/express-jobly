
const db = require("../db");
const { NotFoundError } = require("../expressError");

class User {
  static async applyToJob(username, jobId) {
    const userCheck = await db.query(
      `SELECT username FROM users WHERE username = $1`,
      [username]
    );
    if (!userCheck.rows[0]) throw new NotFoundError(`No user: ${username}`);

    const jobCheck = await db.query(
      `SELECT id FROM jobs WHERE id = $1`,
      [jobId]
    );
    if (!jobCheck.rows[0]) throw new NotFoundError(`No job: ${jobId}`);

    const result = await db.query(
      `INSERT INTO applications (username, job_id)
       VALUES ($1, $2)
       RETURNING job_id AS "jobId"`,
      [username, jobId]
    );
    const application = result.rows[0];

    return application;
  }

  static async getApplications(username) {
    const result = await db.query(
      `SELECT a.job_id
       FROM applications AS a
       WHERE a.username = $1`,
      [username]
    );

    return result.rows.map(a => a.job_id);
  }
}

module.exports = User;
