const { BadRequestError } = require("../expressError");

/**
 * Generates a SQL query fragment for updating specific fields in a table.
 *
 * @param {Object} dataToUpdate - An object containing the fields and their new values.
 *                                Example: {firstName: 'Aliya', age: 32}
 * @param {Object} jsToSql - An object mapping JavaScript-style field names to SQL column names.
 *                           Example: {firstName: 'first_name'}
 *
 * @returns {Object} - An object containing:
 *                     - setCols: A string with the SQL fragment for the SET clause.
 *                     - values: An array of values corresponding to the fields to be updated.
 *
 * @throws {BadRequestError} - If no data is provided to update.
 *
 * Example usage:
 *   sqlForPartialUpdate(
 *     { firstName: 'Aliya', age: 32 },
 *     { firstName: 'first_name' }
 *   );
 *   Returns:
 *   {
 *     setCols: '"first_name"=$1, "age"=$2',
 *     values: ['Aliya', 32]
 *   }
 */
function sqlForPartialUpdate(dataToUpdate, jsToSql) {
  const keys = Object.keys(dataToUpdate);
  if (keys.length === 0) throw new BadRequestError("No data");

  const cols = keys.map((colName, idx) =>
      `"${jsToSql[colName] || colName}"=$${idx + 1}`,
  );

  return {
    setCols: cols.join(", "),
    values: Object.values(dataToUpdate),
  };
}

module.exports = { sqlForPartialUpdate };
