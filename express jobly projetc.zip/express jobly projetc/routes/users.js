const express = require("express");
const { ensureLoggedIn, ensureCorrectUserOrAdmin, ensureAdmin } = require("../middleware/auth");
const User = require("../models/user");
const crypto = require("crypto");
const { createToken } = require("../helpers/tokens");
const router = express.Router();

/** POST /users { user } => { user, token }
 *  Admins can create new users. If no password is provided, a random password is generated.
 *  Returns the newly created user and a token.
 *  Authorization required: admin
 */
router.post("/", ensureAdmin, async function (req, res, next) {
  try {
    const { username, firstName, lastName, email, password } = req.body;

    // Generate a random password if one is not provided
    const userPassword = password || crypto.randomBytes(10).toString("hex");

    const user = await User.register({ username, firstName, lastName, email, password: userPassword, isAdmin: false });
    const token = createToken(user);
    
    // Return user data with token
    return res.status(201).json({ user, token });
  } catch (err) {
    return next(err);
  }
});

/** POST /users/:username/jobs/:id  => { applied: jobId }
 *  Allows a user to apply for a job.
 *  Authorization required: admin or correct user
 **/
router.post("/:username/jobs/:id", ensureCorrectUserOrAdmin, async function (req, res, next) {
  try {
    const { username, id } = req.params;
    const application = await User.applyToJob(username, id);
    return res.status(201).json({ applied: application.jobId });
  } catch (err) {
    return next(err);
  }
});

/** GET /users/:username => { user }
 *  Returns user data along with a list of job IDs the user has applied for.
 *  Authorization required: admin or correct user
 */
router.get("/:username", ensureCorrectUserOrAdmin, async function (req, res, next) {
  try {
    const user = await User.get(req.params.username);
    const applications = await User.getApplications(req.params.username);
    user.jobs = applications;
    return res.json({ user });
  } catch (err) {
    return next(err);
  }
});

/** GET /users  =>  { users: [ { username, firstName, lastName, email }, ...] }
 *  Returns list of all users.
 *  Authorization required: admin
 **/
router.get("/", ensureAdmin, async function (req, res, next) {
  try {
    const users = await User.findAll();
    return res.json({ users });
  } catch (err) {
    return next(err);
  }
});

module.exports = router;
